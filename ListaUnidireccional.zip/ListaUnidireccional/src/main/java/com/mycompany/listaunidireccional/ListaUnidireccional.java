package com.mycompany.listaunidireccional;

public class ListaUnidireccional {

    private Nodo primero;
    private int tamanio;

    public ListaUnidireccional() {
        primero = null;
        tamanio = 0;
    }

    public boolean estaVacia() {
        return primero == null;
    }

    public int getTamanio() {
        return tamanio;
    }

    public void insertarInicio(Producto producto) {
        Nodo nuevo = new Nodo(producto);
        nuevo.setSiguiente(primero);
        primero = nuevo;
        tamanio++;
    }

    public void insertarFinal(Producto producto) {
        Nodo nuevo = new Nodo(producto);

        if (estaVacia()) {
            primero = nuevo;
        } else {
            Nodo actual = primero;

            while (actual.getSiguiente() != null) {
                actual = actual.getSiguiente();
            }

            actual.setSiguiente(nuevo);
        }

        tamanio++;
    }

    public void insertarPosicion(Producto producto, int posicion) {

        if (posicion < 0 || posicion > tamanio) {
            throw new IndexOutOfBoundsException(
                    "La posición debe estar entre 0 y " + tamanio
            );
        }

        if (posicion == 0) {
            insertarInicio(producto);
            return;
        }

        if (posicion == tamanio) {
            insertarFinal(producto);
            return;
        }

        Nodo nuevo = new Nodo(producto);
        Nodo actual = primero;

        for (int i = 0; i < posicion - 1; i++) {
            actual = actual.getSiguiente();
        }

        nuevo.setSiguiente(actual.getSiguiente());
        actual.setSiguiente(nuevo);

        tamanio++;
    }

    public Producto removerInicio() {

        verificarListaVacia();

        Producto eliminado = primero.getDato();
        primero = primero.getSiguiente();

        tamanio--;

        return eliminado;
    }

    public Producto removerFinal() {

        verificarListaVacia();

        if (primero.getSiguiente() == null) {
            Producto eliminado = primero.getDato();
            primero = null;
            tamanio--;
            return eliminado;
        }

        Nodo actual = primero;

        while (actual.getSiguiente().getSiguiente() != null) {
            actual = actual.getSiguiente();
        }

        Producto eliminado = actual.getSiguiente().getDato();

        actual.setSiguiente(null);

        tamanio--;

        return eliminado;
    }

    public Producto removerPosicion(int posicion) {

        verificarPosicion(posicion);

        if (posicion == 0) {
            return removerInicio();
        }

        Nodo actual = primero;

        for (int i = 0; i < posicion - 1; i++) {
            actual = actual.getSiguiente();
        }

        Nodo eliminado = actual.getSiguiente();

        actual.setSiguiente(eliminado.getSiguiente());

        tamanio--;

        return eliminado.getDato();
    }

    public Producto mostrarInicio() {
        verificarListaVacia();
        return primero.getDato();
    }

    public Producto mostrarFinal() {

        verificarListaVacia();

        Nodo actual = primero;

        while (actual.getSiguiente() != null) {
            actual = actual.getSiguiente();
        }

        return actual.getDato();
    }

    public Producto mostrarPosicion(int posicion) {

        verificarPosicion(posicion);

        Nodo actual = primero;

        for (int i = 0; i < posicion; i++) {
            actual = actual.getSiguiente();
        }

        return actual.getDato();
    }

    public Producto buscarPorId(int id) {

        Nodo actual = primero;

        while (actual != null) {

            if (actual.getDato().id() == id) {
                return actual.getDato();
            }

            actual = actual.getSiguiente();
        }

        return null;
    }

    public int buscarPosicionPorId(int id) {

        Nodo actual = primero;
        int posicion = 0;

        while (actual != null) {

            if (actual.getDato().id() == id) {
                return posicion;
            }

            actual = actual.getSiguiente();
            posicion++;
        }

        return -1;
    }

    public boolean existeId(int id) {

        Nodo actual = primero;

        while (actual != null) {

            if (actual.getDato().id() == id) {
                return true;
            }

            actual = actual.getSiguiente();
        }

        return false;
    }

    public void vaciar() {
        primero = null;
        tamanio = 0;
    }

    public String mostrarListaCompleta() {

        if (estaVacia()) {
            return "La lista se encuentra vacía.";
        }

        StringBuilder texto = new StringBuilder();

        Nodo actual = primero;
        int posicion = 0;

        while (actual != null) {

            texto.append("Posición ")
                    .append(posicion)
                    .append(" -> ")
                    .append(actual.getDato())
                    .append("\n");

            actual = actual.getSiguiente();
            posicion++;
        }

        return texto.toString();
    }

    private void verificarListaVacia() {

        if (estaVacia()) {
            throw new IllegalStateException(
                    "La lista está vacía."
            );
        }
    }

    private void verificarPosicion(int posicion) {

        if (posicion < 0 || posicion >= tamanio) {
            throw new IndexOutOfBoundsException(
                    "Posición fuera de rango."
            );
        }
    }
}