package com.mycompany.listaunidireccional;

public record Producto(int id, String nombre, double precio) {

    @Override
    public String toString() {
        return "ID: " + id
                + " | Nombre: " + nombre
                + " | Precio: $" + String.format("%.2f", precio);
    }
}