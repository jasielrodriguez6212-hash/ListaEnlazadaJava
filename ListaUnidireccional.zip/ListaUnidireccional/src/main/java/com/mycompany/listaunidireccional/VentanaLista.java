package com.mycompany.listaunidireccional;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class VentanaLista extends JFrame {

    private final ListaUnidireccional lista;

    private JTextField txtId;
    private JTextField txtNombre;
    private JTextField txtPrecio;
    private JTextField txtPosicion;
    private JTextField txtBuscar;

    private JTextArea areaLista;

    public VentanaLista() {

        lista = new ListaUnidireccional();

        setTitle("Lista Unidireccional - Productos");
        setSize(900, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        iniciarComponentes();
    }

    private void iniciarComponentes() {

        setLayout(new BorderLayout(10, 10));

        // PANEL DE DATOS
        JPanel panelDatos = new JPanel(
                new GridLayout(5, 2, 10, 10)
        );

        panelDatos.setBorder(
                BorderFactory.createTitledBorder(
                        "Datos del producto"
                )
        );

        panelDatos.add(new JLabel("ID:"));
        txtId = new JTextField();
        panelDatos.add(txtId);

        panelDatos.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        panelDatos.add(txtNombre);

        panelDatos.add(new JLabel("Precio:"));
        txtPrecio = new JTextField();
        panelDatos.add(txtPrecio);

        panelDatos.add(new JLabel("Posición:"));
        txtPosicion = new JTextField();
        panelDatos.add(txtPosicion);

        panelDatos.add(new JLabel("ID a buscar:"));
        txtBuscar = new JTextField();
        panelDatos.add(txtBuscar);

        add(panelDatos, BorderLayout.NORTH);

        // PANEL DE BOTONES
        JPanel panelBotones = new JPanel(
                new GridLayout(4, 3, 8, 8)
        );

        panelBotones.setBorder(
                BorderFactory.createTitledBorder(
                        "Operaciones de la lista"
                )
        );

        JButton btnInsertarInicio =
                new JButton("Insertar inicio");

        JButton btnInsertarFinal =
                new JButton("Insertar final");

        JButton btnInsertarPosicion =
                new JButton("Insertar posición");

        JButton btnRemoverInicio =
                new JButton("Remover inicio");

        JButton btnRemoverFinal =
                new JButton("Remover final");

        JButton btnRemoverPosicion =
                new JButton("Remover posición");

        JButton btnMostrarInicio =
                new JButton("Mostrar inicio");

        JButton btnMostrarFinal =
                new JButton("Mostrar final");

        JButton btnMostrarPosicion =
                new JButton("Mostrar posición");

        JButton btnBuscar =
                new JButton("Buscar por ID");

        JButton btnVaciar =
                new JButton("Vaciar lista");

        JButton btnActualizar =
                new JButton("Actualizar lista");

        panelBotones.add(btnInsertarInicio);
        panelBotones.add(btnInsertarFinal);
        panelBotones.add(btnInsertarPosicion);

        panelBotones.add(btnRemoverInicio);
        panelBotones.add(btnRemoverFinal);
        panelBotones.add(btnRemoverPosicion);

        panelBotones.add(btnMostrarInicio);
        panelBotones.add(btnMostrarFinal);
        panelBotones.add(btnMostrarPosicion);

        panelBotones.add(btnBuscar);
        panelBotones.add(btnVaciar);
        panelBotones.add(btnActualizar);

        add(panelBotones, BorderLayout.CENTER);

        // ÁREA DONDE SE MUESTRA LA LISTA
        areaLista = new JTextArea(12, 50);

        areaLista.setEditable(false);

        areaLista.setFont(
                new Font(
                        "Monospaced",
                        Font.PLAIN,
                        14
                )
        );

        JScrollPane scroll =
                new JScrollPane(areaLista);

        scroll.setBorder(
                BorderFactory.createTitledBorder(
                        "Contenido actual de la lista"
                )
        );

        add(scroll, BorderLayout.SOUTH);

        // BOTONES

        btnInsertarInicio.addActionListener(
                e -> insertarInicio()
        );

        btnInsertarFinal.addActionListener(
                e -> insertarFinal()
        );

        btnInsertarPosicion.addActionListener(
                e -> insertarPosicion()
        );

        btnRemoverInicio.addActionListener(
                e -> removerInicio()
        );

        btnRemoverFinal.addActionListener(
                e -> removerFinal()
        );

        btnRemoverPosicion.addActionListener(
                e -> removerPosicion()
        );

        btnMostrarInicio.addActionListener(
                e -> mostrarInicio()
        );

        btnMostrarFinal.addActionListener(
                e -> mostrarFinal()
        );

        btnMostrarPosicion.addActionListener(
                e -> mostrarPosicion()
        );

        btnBuscar.addActionListener(
                e -> buscarProducto()
        );

        btnVaciar.addActionListener(
                e -> vaciarLista()
        );

        btnActualizar.addActionListener(
                e -> actualizarLista()
        );

        actualizarLista();
    }

    // CREAR PRODUCTO CON LOS DATOS DEL FORMULARIO
    private Producto obtenerProducto() {

        if (txtId.getText().trim().isEmpty()
                || txtNombre.getText().trim().isEmpty()
                || txtPrecio.getText().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Debes completar ID, nombre y precio."
            );
        }

        int id =
                Integer.parseInt(
                        txtId.getText().trim()
                );

        String nombre =
                txtNombre.getText().trim();

        double precio =
                Double.parseDouble(
                        txtPrecio.getText().trim()
                );

        if (id < 0) {

            throw new IllegalArgumentException(
                    "El ID no puede ser negativo."
            );
        }

        if (precio < 0) {

            throw new IllegalArgumentException(
                    "El precio no puede ser negativo."
            );
        }

        if (lista.existeId(id)) {

            throw new IllegalArgumentException(
                    "Ya existe un producto con el ID "
                            + id
            );
        }

        return new Producto(
                id,
                nombre,
                precio
        );
    }

    // OBTENER POSICIÓN
    private int obtenerPosicion() {

        if (txtPosicion
                .getText()
                .trim()
                .isEmpty()) {

            throw new IllegalArgumentException(
                    "Debes escribir una posición."
            );
        }

        return Integer.parseInt(
                txtPosicion
                        .getText()
                        .trim()
        );
    }

    // INSERTAR INICIO
    private void insertarInicio() {

        try {

            Producto producto =
                    obtenerProducto();

            lista.insertarInicio(producto);

            JOptionPane.showMessageDialog(
                    this,
                    "Producto insertado al inicio correctamente."
            );

            limpiarCampos();
            actualizarLista();

        } catch (NumberFormatException ex) {

            mostrarError(
                    "El ID y el precio deben ser números."
            );

        } catch (Exception ex) {

            mostrarError(
                    ex.getMessage()
            );
        }
    }

    // INSERTAR FINAL
    private void insertarFinal() {

        try {

            Producto producto =
                    obtenerProducto();

            lista.insertarFinal(producto);

            JOptionPane.showMessageDialog(
                    this,
                    "Producto insertado al final correctamente."
            );

            limpiarCampos();
            actualizarLista();

        } catch (NumberFormatException ex) {

            mostrarError(
                    "El ID y el precio deben ser números."
            );

        } catch (Exception ex) {

            mostrarError(
                    ex.getMessage()
            );
        }
    }

    // INSERTAR POR POSICIÓN
    private void insertarPosicion() {

        try {

            Producto producto =
                    obtenerProducto();

            int posicion =
                    obtenerPosicion();

            lista.insertarPosicion(
                    producto,
                    posicion
            );

            JOptionPane.showMessageDialog(
                    this,
                    "Producto insertado en la posición "
                            + posicion
            );

            limpiarCampos();

            txtPosicion.setText("");

            actualizarLista();

        } catch (NumberFormatException ex) {

            mostrarError(
                    "ID, precio y posición deben ser números."
            );

        } catch (Exception ex) {

            mostrarError(
                    ex.getMessage()
            );
        }
    }

    // REMOVER INICIO
    private void removerInicio() {

        try {

            Producto producto =
                    lista.removerInicio();

            JOptionPane.showMessageDialog(
                    this,
                    "Producto eliminado:\n\n"
                            + producto
            );

            actualizarLista();

        } catch (Exception ex) {

            mostrarError(
                    ex.getMessage()
            );
        }
    }

    // REMOVER FINAL
    private void removerFinal() {

        try {

            Producto producto =
                    lista.removerFinal();

            JOptionPane.showMessageDialog(
                    this,
                    "Producto eliminado:\n\n"
                            + producto
            );

            actualizarLista();

        } catch (Exception ex) {

            mostrarError(
                    ex.getMessage()
            );
        }
    }

    // REMOVER POR POSICIÓN
    private void removerPosicion() {

        try {

            int posicion =
                    obtenerPosicion();

            Producto producto =
                    lista.removerPosicion(
                            posicion
                    );

            JOptionPane.showMessageDialog(
                    this,
                    "Producto eliminado de la posición "
                            + posicion
                            + ":\n\n"
                            + producto
            );

            txtPosicion.setText("");

            actualizarLista();

        } catch (NumberFormatException ex) {

            mostrarError(
                    "La posición debe ser un número entero."
            );

        } catch (Exception ex) {

            mostrarError(
                    ex.getMessage()
            );
        }
    }

    // MOSTRAR INICIO
    private void mostrarInicio() {

        try {

            Producto producto =
                    lista.mostrarInicio();

            JOptionPane.showMessageDialog(
                    this,
                    "Primer producto de la lista:\n\n"
                            + producto
            );

        } catch (Exception ex) {

            mostrarError(
                    ex.getMessage()
            );
        }
    }

    // MOSTRAR FINAL
    private void mostrarFinal() {

        try {

            Producto producto =
                    lista.mostrarFinal();

            JOptionPane.showMessageDialog(
                    this,
                    "Último producto de la lista:\n\n"
                            + producto
            );

        } catch (Exception ex) {

            mostrarError(
                    ex.getMessage()
            );
        }
    }

    // MOSTRAR POR POSICIÓN
    private void mostrarPosicion() {

        try {

            int posicion =
                    obtenerPosicion();

            Producto producto =
                    lista.mostrarPosicion(
                            posicion
                    );

            JOptionPane.showMessageDialog(
                    this,
                    "Producto de la posición "
                            + posicion
                            + ":\n\n"
                            + producto
            );

        } catch (NumberFormatException ex) {

            mostrarError(
                    "La posición debe ser un número entero."
            );

        } catch (Exception ex) {

            mostrarError(
                    ex.getMessage()
            );
        }
    }

    // BUSCAR POR ID
    private void buscarProducto() {

        try {

            if (txtBuscar
                    .getText()
                    .trim()
                    .isEmpty()) {

                throw new IllegalArgumentException(
                        "Escribe el ID que deseas buscar."
                );
            }

            int id =
                    Integer.parseInt(
                            txtBuscar
                                    .getText()
                                    .trim()
                    );

            Producto producto =
                    lista.buscarPorId(id);

            if (producto == null) {

                JOptionPane.showMessageDialog(
                        this,
                        "No se encontró un producto con el ID "
                                + id,
                        "Búsqueda",
                        JOptionPane.INFORMATION_MESSAGE
                );

            } else {

                int posicion =
                        lista.buscarPosicionPorId(id);

                JOptionPane.showMessageDialog(
                        this,
                        "Producto encontrado\n\n"
                                + producto
                                + "\n\nPosición: "
                                + posicion
                );
            }

        } catch (NumberFormatException ex) {

            mostrarError(
                    "El ID de búsqueda debe ser un número."
            );

        } catch (Exception ex) {

            mostrarError(
                    ex.getMessage()
            );
        }
    }

    // VACIAR LISTA
    private void vaciarLista() {

        if (lista.estaVacia()) {

            JOptionPane.showMessageDialog(
                    this,
                    "La lista ya está vacía."
            );

            return;
        }

        int respuesta =
                JOptionPane.showConfirmDialog(
                        this,
                        "¿Seguro que deseas vaciar toda la lista?",
                        "Vaciar lista",
                        JOptionPane.YES_NO_OPTION
                );

        if (respuesta
                == JOptionPane.YES_OPTION) {

            lista.vaciar();

            actualizarLista();

            JOptionPane.showMessageDialog(
                    this,
                    "La lista se vació correctamente."
            );
        }
    }

    // ACTUALIZAR CONTENIDO
    private void actualizarLista() {

        areaLista.setText(
                "Cantidad de elementos: "
                        + lista.getTamanio()
                        + "\n"
                        + "---------------------------------------------"
                        + "\n\n"
                        + lista.mostrarListaCompleta()
        );
    }

    // LIMPIAR CAMPOS
    private void limpiarCampos() {

        txtId.setText("");
        txtNombre.setText("");
        txtPrecio.setText("");
    }

    // MOSTRAR ERROR
    private void mostrarError(
            String mensaje
    ) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }

    // MAIN
    public static void main(
            String[] args
    ) {

        SwingUtilities.invokeLater(
                () -> {

                    VentanaLista ventana =
                            new VentanaLista();

                    ventana.setVisible(true);
                }
        );
    }
}